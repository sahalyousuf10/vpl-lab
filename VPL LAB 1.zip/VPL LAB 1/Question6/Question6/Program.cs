﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question6
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 1st number\n");
            String num1 = Console.ReadLine();
            Console.WriteLine("Enter 2nd number\n");
            String num2 = Console.ReadLine();
            Console.WriteLine("Enter the operator\n");
            String op = Console.ReadLine();
            int a = Int32.Parse(num1);
            int b = Int32.Parse(num2);


            int add, sub, div, mul;
            add = a + b;
            sub = a - b;
            div = a / b;
            mul = a * b;

            switch (op)
            {
                case "+":
                    Console.WriteLine("Result is" + add);
                    break;
                case "-":
                    Console.WriteLine("Result is" + sub);
                    break;
                case "*":
                    Console.WriteLine("Result is" + mul);
                    break;
                case "/":
                    Console.WriteLine("Result is" + div);
                    break;


            }

            Console.ReadLine();

        }
    }
}
