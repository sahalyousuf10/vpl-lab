﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter 1st number\n");
            String num1 = Console.ReadLine();
            Console.WriteLine("Enter 2nd number\n");
            String num2 = Console.ReadLine();
            Console.WriteLine("Enter 3rd number\n");
            String num3 = Console.ReadLine();
            int a = Int32.Parse(num1);
            int b = Int32.Parse(num2);
            int c = Int32.Parse(num3);

            if (a > b && a > c)
                Console.WriteLine(a + "\tIs the maximum number\n");
            else if (b > a && b > c)
                Console.WriteLine(b + "\tIs the maximum number\n");
            else
                Console.WriteLine(c + "\tIs the maximum number\n");
            if (a < b && a < c)
                Console.WriteLine(a + "\tIs the minimum number\n");
            else if (b < a && b < c)
                Console.WriteLine(b + "\tIs the minimum number\n");
            else
                Console.WriteLine(c + "\tIs the minimum number\n");
            Console.ReadLine();

        }
    }
}
