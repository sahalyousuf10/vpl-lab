﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question7
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter obtained marks in vpl lab\n");
            String num1 = Console.ReadLine();
            int a = Int32.Parse(num1);

            if (a >= 60 && a < 68)
            {
                Console.WriteLine("The grade is C\n Gpa is 2\n");
            }

            else if (a >= 68 && a < 73)
            {
                Console.WriteLine("The grade is C+\n Gpa is 2.5\n");
            }

            else if (a >= 73 && a < 81)
            {
                Console.WriteLine("The grade is B\n Gpa is 3\n");
            }

            else if (a >= 81 && a < 88)
            {
                Console.WriteLine("The grade is B+\n Gpa is 3.5\n");
            }

            else if (a >= 88)
            {
                Console.WriteLine("The grade is A\n Gpa is 4");
            }

            else
            {
                Console.WriteLine("The grade is F\n Gpa is 0");
            }

            Console.ReadLine();

        }
    }
}
