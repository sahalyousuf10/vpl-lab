﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the month");
            String num = Console.ReadLine();
            int a = Int32.Parse(num);

            if (a == 12 || a == 1 || a == 2)
            {
                Console.WriteLine("The season is summer");
            }

            else if (a == 3 || a == 4 || a == 5)
            {
                Console.WriteLine("The season is Autumn");

            }
            else if (a == 6 || a == 7 || a == 8)
            {
                Console.WriteLine("The season is Winter");
            }

            else if (a == 9 || a == 10 || a == 11)
            {
                Console.WriteLine("The season is Spring");
            }
            else
            {
                Console.WriteLine("Invalid number");
            }

            Console.ReadLine();


        }
    }
}
