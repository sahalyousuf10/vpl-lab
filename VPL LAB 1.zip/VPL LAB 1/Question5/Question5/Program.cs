﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question5
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the Year");
            String num = Console.ReadLine();
            int year = Int32.Parse(num);


            if (year % 4 == 0)
            {
                if (year % 100 == 0)
                {

                    if (year % 400 == 0)
                        Console.WriteLine(year + "is a leap year.");
                    else
                        Console.WriteLine(year + "is not a leap year.");
                }
                else
                    Console.WriteLine(year + "is a leap year.");
            }
            else
                Console.WriteLine(year + " is not a leap year.");


            Console.ReadLine();

        }
    }
}
