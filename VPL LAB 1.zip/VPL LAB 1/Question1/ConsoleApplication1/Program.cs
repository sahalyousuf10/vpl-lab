﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question1
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("::::CURRICULM VIATE:::::");
            Console.WriteLine("Name: Mohammad Sahal Yousuf");
            Console.WriteLine("Citizenship: Pakistani");
            Console.WriteLine("Contact Number: 03007402380");
            Console.WriteLine("Email: sahal.yousuf10@gmail.com");
            Console.WriteLine("Cnic no: 42101-6668013-7");
            Console.WriteLine("Address: H.no LS-42/2 azizabad f.b abrea karachi");
            Console.WriteLine("Qualification:\n Mariculation\n Intermediate\ngraduation");
            Console.ReadLine();

        }
    }
}
