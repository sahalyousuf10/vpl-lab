﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the number");
            String num = Console.ReadLine();
            int a = Int32.Parse(num);
            if (a % 2 == 0)
            {
                Console.WriteLine("Tne number is even");
            }
            else
            {
                Console.WriteLine("Tne number is odd");
            }
            Console.ReadLine();

        }
    }
}
